# https://velog.io/@taki0412

Contact: Velog
Icon: https://www.pngarts.com/files/2/Letter-V-PNG-Background-Image.png