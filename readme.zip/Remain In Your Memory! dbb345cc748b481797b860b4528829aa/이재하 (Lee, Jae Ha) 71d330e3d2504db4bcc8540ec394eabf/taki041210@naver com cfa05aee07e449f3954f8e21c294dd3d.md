# taki041210@naver.com

Contact: Maill
Icon: https://www.notion.so/d03df72be8d84232a2797ea4eec5bc06